/**
 * API base URL — read from CRA env variable.
 * Add a .env file at the frontend root with:
 *   REACT_APP_API_BASE_URL=http://localhost:8765
 * The package.json proxy field handles same-origin dev requests if preferred.
 */
export const API_BASE_URL: string =
  process.env.REACT_APP_API_BASE_URL || 'http://localhost:8765';
